package Abstraction.Exercise.GreedyTimes;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        long bagCapacity = Long.parseLong(scanner.nextLine());
        String[] lootData = scanner.nextLine().split("\\s+");

        Map<String, LinkedHashMap<String, Long>> bagMap = new LinkedHashMap<>();


        for (int i = 0; i < lootData.length; i += 2) {
            String currentItemName = lootData[i];
            long quantity = Long.parseLong(lootData[i + 1]);

            String currentItem = "";

            if (currentItemName.length() == 3) {
                currentItem = "Cash";
            } else if (currentItemName.toLowerCase().endsWith("gem")) {
                currentItem = "Gem";
            } else if (currentItemName.equalsIgnoreCase("gold")) {
                currentItem = "Gold";
            }

            if (currentItem.equals("")) {
                continue;
            } else if (bagCapacity < bagMap.values().stream().map(Map::values).flatMap(Collection::stream).mapToLong(e -> e).sum() + quantity) {
                continue;
            }

            switch (currentItem) {
                case "Gem":
                    if (!bagMap.containsKey(currentItem)) {
                        if (bagMap.containsKey("Gold")) {
                            if (quantity > bagMap.get("Gold").values().stream().mapToLong(e -> e).sum()) {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    } else if (bagMap.get(currentItem).values().stream().mapToLong(e -> e).sum() + quantity > bagMap.get("Gold").values().stream().mapToLong(e -> e).sum()) {
                        continue;
                    }
                    break;
                case "Cash":
                    if (!bagMap.containsKey(currentItem)) {
                        if (bagMap.containsKey("Gem")) {
                            if (quantity > bagMap.get("Gold").values().stream().mapToLong(e -> e).sum()) {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    } else if (bagMap.get(currentItem).values().stream().mapToLong(e -> e).sum() + quantity > bagMap.get("Gem").values().stream().mapToLong(e -> e).sum()) {
                        continue;
                    }
                    break;
            }

            if (!bagMap.containsKey(currentItem)) {
                bagMap.put((currentItem), new LinkedHashMap<String, Long>());
            }

            if (!bagMap.get(currentItem).containsKey(currentItemName)) {
                bagMap.get(currentItem).put(currentItemName, 0L);
            }


            bagMap.get(currentItem).put(currentItemName, bagMap.get(currentItem).get(currentItemName) + quantity);

        }

        for (var x : bagMap.entrySet()) {
            Long sumValues = x.getValue().values().stream().mapToLong(l -> l).sum();

            System.out.println(String.format("<%s> $%s", x.getKey(), sumValues));

            x.getValue().entrySet().stream().sorted((e1, e2) -> e2.getKey().compareTo(e1.getKey())).forEach(i -> System.out.println("##" + i.getKey() + " - " + i.getValue()));

        }
    }
}